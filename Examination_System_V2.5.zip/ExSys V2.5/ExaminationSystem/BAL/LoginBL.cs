﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ExaminationSystem.BAL
{
    class LoginBL
    {
    }
}
