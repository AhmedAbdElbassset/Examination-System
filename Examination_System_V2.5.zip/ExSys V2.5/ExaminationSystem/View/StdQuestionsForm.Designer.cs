﻿
namespace ExaminationSystem
{
    partial class StdQuestionsForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.QCombo9 = new System.Windows.Forms.ComboBox();
            this.QCombo8 = new System.Windows.Forms.ComboBox();
            this.QCombo7 = new System.Windows.Forms.ComboBox();
            this.QCombo6 = new System.Windows.Forms.ComboBox();
            this.QCombo5 = new System.Windows.Forms.ComboBox();
            this.QCombo4 = new System.Windows.Forms.ComboBox();
            this.QCombo3 = new System.Windows.Forms.ComboBox();
            this.QCombo2 = new System.Windows.Forms.ComboBox();
            this.QCombo1 = new System.Windows.Forms.ComboBox();
            this.QCombo0 = new System.Windows.Forms.ComboBox();
            this.button1 = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.panel1.AutoSize = true;
            this.panel1.Controls.Add(this.QCombo9);
            this.panel1.Controls.Add(this.QCombo8);
            this.panel1.Controls.Add(this.QCombo7);
            this.panel1.Controls.Add(this.QCombo6);
            this.panel1.Controls.Add(this.QCombo5);
            this.panel1.Controls.Add(this.QCombo4);
            this.panel1.Controls.Add(this.QCombo3);
            this.panel1.Controls.Add(this.QCombo2);
            this.panel1.Controls.Add(this.QCombo1);
            this.panel1.Controls.Add(this.QCombo0);
            this.panel1.Location = new System.Drawing.Point(493, 12);
            this.panel1.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(409, 805);
            this.panel1.TabIndex = 1;
            // 
            // QCombo9
            // 
            this.QCombo9.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.QCombo9.FormattingEnabled = true;
            this.QCombo9.Location = new System.Drawing.Point(14, 741);
            this.QCombo9.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.QCombo9.Name = "QCombo9";
            this.QCombo9.Size = new System.Drawing.Size(375, 28);
            this.QCombo9.TabIndex = 9;
            // 
            // QCombo8
            // 
            this.QCombo8.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.QCombo8.FormattingEnabled = true;
            this.QCombo8.Location = new System.Drawing.Point(14, 661);
            this.QCombo8.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.QCombo8.Name = "QCombo8";
            this.QCombo8.Size = new System.Drawing.Size(375, 28);
            this.QCombo8.TabIndex = 8;
            // 
            // QCombo7
            // 
            this.QCombo7.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.QCombo7.FormattingEnabled = true;
            this.QCombo7.Location = new System.Drawing.Point(14, 583);
            this.QCombo7.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.QCombo7.Name = "QCombo7";
            this.QCombo7.Size = new System.Drawing.Size(375, 28);
            this.QCombo7.TabIndex = 7;
            // 
            // QCombo6
            // 
            this.QCombo6.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.QCombo6.FormattingEnabled = true;
            this.QCombo6.Location = new System.Drawing.Point(14, 500);
            this.QCombo6.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.QCombo6.Name = "QCombo6";
            this.QCombo6.Size = new System.Drawing.Size(375, 28);
            this.QCombo6.TabIndex = 6;
            // 
            // QCombo5
            // 
            this.QCombo5.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.QCombo5.FormattingEnabled = true;
            this.QCombo5.Location = new System.Drawing.Point(14, 408);
            this.QCombo5.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.QCombo5.Name = "QCombo5";
            this.QCombo5.Size = new System.Drawing.Size(375, 28);
            this.QCombo5.TabIndex = 5;
            // 
            // QCombo4
            // 
            this.QCombo4.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.QCombo4.FormattingEnabled = true;
            this.QCombo4.Location = new System.Drawing.Point(14, 332);
            this.QCombo4.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.QCombo4.Name = "QCombo4";
            this.QCombo4.Size = new System.Drawing.Size(375, 28);
            this.QCombo4.TabIndex = 4;
            // 
            // QCombo3
            // 
            this.QCombo3.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.QCombo3.FormattingEnabled = true;
            this.QCombo3.Location = new System.Drawing.Point(14, 248);
            this.QCombo3.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.QCombo3.Name = "QCombo3";
            this.QCombo3.Size = new System.Drawing.Size(375, 28);
            this.QCombo3.TabIndex = 3;
            // 
            // QCombo2
            // 
            this.QCombo2.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.QCombo2.FormattingEnabled = true;
            this.QCombo2.Location = new System.Drawing.Point(14, 163);
            this.QCombo2.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.QCombo2.Name = "QCombo2";
            this.QCombo2.Size = new System.Drawing.Size(375, 28);
            this.QCombo2.TabIndex = 2;
            // 
            // QCombo1
            // 
            this.QCombo1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.QCombo1.FormattingEnabled = true;
            this.QCombo1.Location = new System.Drawing.Point(14, 84);
            this.QCombo1.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.QCombo1.Name = "QCombo1";
            this.QCombo1.Size = new System.Drawing.Size(375, 28);
            this.QCombo1.TabIndex = 1;
            // 
            // QCombo0
            // 
            this.QCombo0.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.QCombo0.FormattingEnabled = true;
            this.QCombo0.Location = new System.Drawing.Point(14, 19);
            this.QCombo0.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.QCombo0.Name = "QCombo0";
            this.QCombo0.Size = new System.Drawing.Size(375, 28);
            this.QCombo0.TabIndex = 0;
            // 
            // button1
            // 
            this.button1.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
            this.button1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(24)))), ((int)(((byte)(182)))), ((int)(((byte)(232)))));
            this.button1.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.button1.ForeColor = System.Drawing.Color.White;
            this.button1.Location = new System.Drawing.Point(358, 832);
            this.button1.Margin = new System.Windows.Forms.Padding(0);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(176, 56);
            this.button1.TabIndex = 5;
            this.button1.Text = "Submit Exam";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label1.Location = new System.Drawing.Point(14, 16);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(38, 23);
            this.label1.TabIndex = 6;
            this.label1.Text = "Q1.";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label2.Location = new System.Drawing.Point(14, 95);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(38, 23);
            this.label2.TabIndex = 7;
            this.label2.Text = "Q2.";
            this.label2.Click += new System.EventHandler(this.label2_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label3.Location = new System.Drawing.Point(14, 176);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(38, 23);
            this.label3.TabIndex = 8;
            this.label3.Text = "Q3.";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label4.Location = new System.Drawing.Point(14, 259);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(38, 23);
            this.label4.TabIndex = 9;
            this.label4.Text = "Q4.";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label5.Location = new System.Drawing.Point(14, 345);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(38, 23);
            this.label5.TabIndex = 10;
            this.label5.Text = "Q5.";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label6.Location = new System.Drawing.Point(14, 425);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(38, 23);
            this.label6.TabIndex = 11;
            this.label6.Text = "Q6.";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label7.Location = new System.Drawing.Point(14, 511);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(38, 23);
            this.label7.TabIndex = 12;
            this.label7.Text = "Q7.";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label8.Location = new System.Drawing.Point(14, 596);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(38, 23);
            this.label8.TabIndex = 13;
            this.label8.Text = "Q8.";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label9.Location = new System.Drawing.Point(14, 675);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(38, 23);
            this.label9.TabIndex = 14;
            this.label9.Text = "Q9.";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label10.Location = new System.Drawing.Point(14, 765);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(48, 23);
            this.label10.TabIndex = 15;
            this.label10.Text = "Q10.";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label11.Location = new System.Drawing.Point(54, 16);
            this.label11.MaximumSize = new System.Drawing.Size(446, 80);
            this.label11.MinimumSize = new System.Drawing.Size(50, 20);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(69, 23);
            this.label11.TabIndex = 17;
            this.label11.Text = "label11";
            this.label11.Click += new System.EventHandler(this.label11_Click);
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label12.Location = new System.Drawing.Point(54, 95);
            this.label12.MaximumSize = new System.Drawing.Size(446, 80);
            this.label12.MinimumSize = new System.Drawing.Size(50, 20);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(69, 23);
            this.label12.TabIndex = 18;
            this.label12.Text = "label12";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label13.Location = new System.Drawing.Point(54, 176);
            this.label13.MaximumSize = new System.Drawing.Size(446, 80);
            this.label13.MinimumSize = new System.Drawing.Size(50, 20);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(69, 23);
            this.label13.TabIndex = 19;
            this.label13.Text = "label13";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label14.Location = new System.Drawing.Point(54, 259);
            this.label14.MaximumSize = new System.Drawing.Size(446, 80);
            this.label14.MinimumSize = new System.Drawing.Size(50, 20);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(69, 23);
            this.label14.TabIndex = 20;
            this.label14.Text = "label14";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label15.Location = new System.Drawing.Point(54, 345);
            this.label15.MaximumSize = new System.Drawing.Size(446, 80);
            this.label15.MinimumSize = new System.Drawing.Size(50, 20);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(69, 23);
            this.label15.TabIndex = 21;
            this.label15.Text = "label15";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label16.Location = new System.Drawing.Point(54, 425);
            this.label16.MaximumSize = new System.Drawing.Size(446, 80);
            this.label16.MinimumSize = new System.Drawing.Size(50, 20);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(69, 23);
            this.label16.TabIndex = 22;
            this.label16.Text = "label16";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label17.Location = new System.Drawing.Point(54, 511);
            this.label17.MaximumSize = new System.Drawing.Size(446, 80);
            this.label17.MinimumSize = new System.Drawing.Size(50, 20);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(69, 23);
            this.label17.TabIndex = 23;
            this.label17.Text = "label17";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label18.Location = new System.Drawing.Point(54, 596);
            this.label18.MaximumSize = new System.Drawing.Size(446, 80);
            this.label18.MinimumSize = new System.Drawing.Size(50, 20);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(69, 23);
            this.label18.TabIndex = 24;
            this.label18.Text = "label18";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label19.Location = new System.Drawing.Point(54, 679);
            this.label19.MaximumSize = new System.Drawing.Size(446, 80);
            this.label19.MinimumSize = new System.Drawing.Size(50, 20);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(69, 23);
            this.label19.TabIndex = 25;
            this.label19.Text = "label19";
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label20.Location = new System.Drawing.Point(54, 765);
            this.label20.MaximumSize = new System.Drawing.Size(446, 80);
            this.label20.MinimumSize = new System.Drawing.Size(50, 20);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(69, 23);
            this.label20.TabIndex = 26;
            this.label20.Text = "label20";
            // 
            // StdQuestionsForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoScroll = true;
            this.AutoSize = true;
            this.BackColor = System.Drawing.Color.AliceBlue;
            this.ClientSize = new System.Drawing.Size(914, 908);
            this.Controls.Add(this.label20);
            this.Controls.Add(this.label19);
            this.Controls.Add(this.label18);
            this.Controls.Add(this.label17);
            this.Controls.Add(this.label16);
            this.Controls.Add(this.label15);
            this.Controls.Add(this.label14);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.panel1);
            this.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.MaximizeBox = false;
            this.Name = "StdQuestionsForm";
            this.Text = "StdQuestionsForm";
            this.Load += new System.EventHandler(this.StdQuestionsForm_Load);
            this.panel1.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.ComboBox Q10Combo;
        private System.Windows.Forms.ComboBox Q9Combo;
        private System.Windows.Forms.ComboBox Q8Combo;
        private System.Windows.Forms.ComboBox Q7Combo;
        private System.Windows.Forms.ComboBox Q6Combo;
        private System.Windows.Forms.ComboBox Q5Combo;
        private System.Windows.Forms.ComboBox Q4Combo;
        private System.Windows.Forms.ComboBox Q3Combo;
        private System.Windows.Forms.ComboBox Q2Combo;
        private System.Windows.Forms.ComboBox Q1Combo;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.ComboBox QCombo9;
        private System.Windows.Forms.ComboBox QCombo8;
        private System.Windows.Forms.ComboBox QCombo7;
        private System.Windows.Forms.ComboBox QCombo6;
        private System.Windows.Forms.ComboBox QCombo5;
        private System.Windows.Forms.ComboBox QCombo4;
        private System.Windows.Forms.ComboBox QCombo3;
        private System.Windows.Forms.ComboBox QCombo2;
        private System.Windows.Forms.ComboBox QCombo1;
        private System.Windows.Forms.ComboBox QCombo0;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label20;
    }
}